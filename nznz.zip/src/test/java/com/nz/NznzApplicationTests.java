package com.nz;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NznzApplicationTests {

	@Test
	void contextLoads() {
	}

}
